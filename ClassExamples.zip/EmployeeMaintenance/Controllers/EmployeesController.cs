﻿using BizLogic.BusinessLogic;
using BizLogic.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EmployeeMaintenance.Controllers
{
  public class EmployeesController : Controller
  {
    NorthwindContext db = new NorthwindContext();
    // GET: Employees
    public ActionResult Index()
    {
      //var db = new NorthwindContext();
      var employees = db.Employees;
      return View(employees);
    }

    public ActionResult Edit(int id)
    {
      //Read the one employee
      Employee e = db.Employees.Find(id);

      return View(e);
    }
  }
}