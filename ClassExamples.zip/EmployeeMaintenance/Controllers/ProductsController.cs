﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using BizLogic.BusinessLogic;
using BizLogic.DataAccess;

namespace EmployeeMaintenance.Controllers
{
  public class ProductsController : Controller
  {
    //private NorthwindContext db = new NorthwindContext();
    private ProductRepository _repo = new ProductRepository();

    public ActionResult Search()
    {
      var list = new List<Product>();
      return View(list);
    }

    [HttpPost]
    public ActionResult Search(string searchString)
    {
      return View(_repo.Get(searchString));
    }
    // GET: Products
    public ActionResult Index()
    {
      return View(_repo.List());
    }

    // GET: Products/Details/5
    public ActionResult Details(int? id)
    {
      if (id == null)
      {
        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
      }
      Product product = _repo.Get(id);
      if (product == null)
      {
        return HttpNotFound();
      }
      return View(product);
    }

    // GET: Products/Create
    public ActionResult Create()
    {
      return View();
    }

    // POST: Products/Create
    [HttpPost]
    [ValidateAntiForgeryToken]
    public ActionResult Create(Product product)
    {
      if (ModelState.IsValid)
      {
        _repo.Add(product);
        return RedirectToAction("Index");
      }

      return View(product);
    }

    // GET: Products/Edit/5
    public ActionResult Edit(int? id)
    {
      if (id == null)
      {
        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
      }
      Product product = _repo.Get(id);
      if (product == null)
      {
        return HttpNotFound();
      }
      return View(product);
    }

    // POST: Products/Edit/5
    [HttpPost]
    [ValidateAntiForgeryToken]
    public ActionResult Edit(Product product)
    {
      if (ModelState.IsValid)
      {
        _repo.Update(product);
        return RedirectToAction("Index");
      }
      return View(product);
    }

    // GET: Products/Delete/5
    public ActionResult Delete(int? id)
    {
      if (id == null)
      {
        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
      }
      Product product = _repo.Get(id);
      if (product == null)
      {
        return HttpNotFound();
      }
      return View(product);
    }

    // POST: Products/Delete/5
    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public ActionResult DeleteConfirmed(int id)
    {
      
      Product product = _repo.Get(id);
      _repo.Delete(product);
      return RedirectToAction("Index");
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing)
      {
        //_repo.Dispose();
      }
      base.Dispose(disposing);
    }
  }
}
