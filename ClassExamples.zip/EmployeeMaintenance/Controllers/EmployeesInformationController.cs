﻿using BizLogic.BusinessLogic;
using EmployeeMaintenance.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EmployeeMaintenance.Controllers
{
  public class EmployeesInformationController : Controller
  {
    // GET: EmployeesInformation
    public ActionResult Index()
    {
      //Create a list of employees
      var employeeList = new List<Employee>();
      var e1 = new Employee() { Address = "805 Moberly Lane", City = "Bentonville", PostalCode = "72702", FirstName = "Sridevi", LastName = "Muppalla" };
      employeeList.Add(e1);

      //Connect to database
      var conn = new SqlConnection();
      conn.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename='C:\Users\Rap\Documents\Visual Studio 2015\Projects\ClassExamples\EmployeeMaintenance\App_Data\NORTHWND.MDF';Integrated Security=True";
      conn.Open();

      //Prepare the select statement
      var cmd = new SqlCommand("select * from employees", conn);
      var rdr = cmd.ExecuteReader();

      //Read each record, make it an employee, and add it to employeeList
      while (rdr.Read())
      {
        var e = new Employee()
        {
          EmployeeID = Convert.ToInt32(rdr["EmployeeID"]),
          Address = rdr["Address"].ToString(),
          BirthDate = Convert.ToDateTime(rdr["BirthDate"]),
          City = rdr["City"].ToString(),
          FirstName = rdr["FirstName"].ToString(),
          LastName = rdr["LastName"].ToString(),
          HomePhone = rdr["HomePHone"].ToString(),
          Region = rdr["Region"].ToString(),
          PostalCode = rdr["PostalCode"].ToString(),
          Country = rdr["Country"].ToString(),
          Title = rdr["Title"].ToString()
        };
        employeeList.Add(e);
    }

      //Close the database
      conn.Close();

      return View(employeeList);
    }
  }
}