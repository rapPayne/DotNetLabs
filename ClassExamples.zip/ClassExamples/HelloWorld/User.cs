﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
  public class User
  {
    public string first { get; set; }
    public string last { get; set; }
    public int id { get; set; }
    private short? _age;
    public short? age
    {
      get
      {
        return _age;
      }
      set
      {
        if (value < 0 || value > 200)
          throw new InputValidationException("Invalid age. Cannot be less than 0 or more than 200.");

        _age = value;
      }
    }


    public bool logIn()
    {
      Console.WriteLine("logged in.");
      return true;
    }

    public void register()
    {
      Console.WriteLine("Registering {0} {1}.", this.first, this.last);
    }
  }
}
