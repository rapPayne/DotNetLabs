﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld.DataAccess
{
  class Queries
  {
    public string TableName;
  }
}
