﻿using HelloWorld.DataAccess;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HelloWorld
{
  public partial class Form1 : Form
  {
    public Form1()
    {
      InitializeComponent();
      // Create users here
    }


    private void SayHello(object sender, EventArgs e)
    {
      this.errorLabel.Text = string.Empty;

      var user = new HelloWorld.User();
      bool isLoggedIn = user.logIn();
      try
      {
        user.first = firstTextbox.Text;
        user.age = Convert.ToInt16(ageTextbox.Text);
        user.last = "Devi";

      }
      catch(InputValidationException)
      {
        this.errorLabel.Text = "Age is too big or too small";
        return;
      }
      catch(Exception ex)
      {
          this.errorLabel.Text = "Some error occurred: " + ex.Message;
          return;
      }
      finally
      {
        MessageBox.Show("Logged in: " + isLoggedIn);
      }


      MessageBox.Show("Hello " + user.first + ". Age: " + user.age);

    }

  }

 
}
