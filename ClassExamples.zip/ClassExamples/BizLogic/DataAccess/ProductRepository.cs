﻿using BizLogic.BusinessLogic;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BizLogic.DataAccess
{
  public class ProductRepository
  {
    private NorthwindContext _db = new NorthwindContext();

    public void  Update(Product product)
    {
      _db.Entry(product).State = EntityState.Modified;
      _db.SaveChanges();
    }

    public void Add(Product product)
    {
      _db.Products.Add(product);
      _db.SaveChanges();
    }

    public void Delete(Product product)
    {
      _db.Products.Remove(product);
      _db.SaveChanges();
    }

    public IEnumerable<Product> List()
    {
      return _db.Products.ToList();
    }

    public Product Get(int? productID)
    {
      if (productID.HasValue)
        return _db.Products.Find(productID.Value);
      else
        throw new Exception("I need a product ID");
    }

    public IEnumerable<Product> Get(string searchString)
    {
      return _db.Products
        .Where(p => p.ProductName.ToLower().Contains(searchString))
        .ToList();
    }
  }
}
