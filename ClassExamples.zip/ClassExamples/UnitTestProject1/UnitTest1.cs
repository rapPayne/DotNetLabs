﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using HelloWorld;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using EmployeeMaintenance.Models;
using BizLogic.BusinessLogic;
using BizLogic.DataAccess;

namespace UnitTestProject1
{
  [TestClass]
  public class UnitTest1
  {
    [TestMethod]
    public void CanAddAnEmployee()
    {
      var db = new NorthwindContext();
      var before = db.Employees.Count();
      var newEmployee = new Employee()
      {
        FirstName = "John",
        LastName = "Wayne",
        Address = "Anywhere in US",
        City = "Anytown",
        Country = "US",
        Region = "TW",
        BirthDate = DateTime.Now.AddYears(-90),
      };


      db.Employees.Add(newEmployee);
      db.SaveChanges();

      var id = newEmployee.EmployeeID;
      Debug.WriteLine($"You added {newEmployee.FirstName}");

      var middle = db.Employees.Count();
      Assert.AreEqual(before + 1, middle);

      var theDeletedOne = db.Employees.Where(e => e.LastName == "Wayne").Single();
      db.Employees.Remove(theDeletedOne);
      db.SaveChanges();

      var after = db.Employees.Count();
      Assert.AreEqual(before, after);

      //var beforeUsers = 10;
      //var afterusers = 11;
      //Assert.AreEqual(beforeUsers + 1, afterusers);
    }
    [TestMethod]
    public void CanLoopThroughUsers()
    {

      var user1 = new User() { first = "Jaya", last = "Natarajan", age = 29, id = 1 };
      var user2 = new User() { first = "Sridevi", last = "Muppalla", age = 30, id = 1 };
      var user3 = new User() { first = "Irma", last = "Garcia", age = 27, id = 1 };
      var user4 = new User() { first = "Mahmud", last = "Hasan", age =32, id = 1 };
      var user5 = new User() { first = "Darren", last = "Carter", age = 31, id = 1 };
      var user6 = new User() { first = "Anusha", last = "Guntaka", age = 28, id = 1 };
      var user7 = new User() { first = "Erica", last = "Rufrano", age = 33, id = 1 };
      var user8 = new User() { first = "Jeba", last = "Siluvaignanamani", age = 31, id = 1 };

      var users = new List<User>() { user1, user2, user3, user4, user5, user6, user7, user8 };

      //var finalList = new List<User>();
      //foreach (User u in users)
      //{
      //  if (u.last.ToUpper().StartsWith("G"))
      //  {
      //    usersWhoStartWithG.Add(u);
      //  }
      //}

      // Where clause
      //var finalList = users.Where(u => u.last.ToUpper().StartsWith("M"));

      // Query syntax
      //var finalList = from u in users
      //                         where u.last.ToUpper().StartsWith("G")
      //                         select u;

      // OrderBy
      //var finalList = users
      //  .OrderBy(u => u.last)
      //  .Select(u => new Employee() { EmployeeID = u.id, firstName = u.first, lastName = u.last });

      var db = new NorthwindContext();

      var finalList = db.Products
        .Where(p => p.UnitsInStock < p.ReorderLevel)
        .Where(p => p.Discontinued == false)
        .Select(p => new { Description=p.ProductName, Qty=p.QuantityPerUnit})
        .ToList();
     
      //Debug.WriteLine("The user is " + finalList.first);
      foreach (var p in finalList)
      {
        Debug.WriteLine(p.Description);
      }
    }

  }

}
